<div class="row">

  <div class="col-lg-12">
    <p>RPirrigate made by <a href="http://bobvann.noip.me" target="_blank">Bob Vann</a></p><br/>
    <ul class="list-unstyled">
      <li>
        <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">
            <img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" />
        </a>
      </li>
      <li><a href="http://bobvann.noip.me/category/rpirrigate/" target="_blank">Blog</a></li>
      <li><a href="https://twitter.com/b0b_Vann" target="_blank" rel="nofollow">Twitter</a></li>
      <li><a href="" target="_blank" rel="nofollow">GitHub</a></li>
    </ul>
    <p><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">RPirrigate</span> is licensed under a 
        <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">
          Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License</a>.</p>
    <p>Based on Bootswatch made by <a href="http://thomaspark.co/" target="_blank" rel="nofollow">Thomas Park</a> and Code released under the <b>MIT</b> license</p>
    <p>Based on <a href="http://getbootstrap.com" rel="nofollow">Bootstrap</a>. Icons from <a href="http://fortawesome.github.io/Font-Awesome/" rel="nofollow">Font Awesome</a>. Web fonts from <a href="http://www.google.com/webfonts" rel="nofollow">Google</a>.</p>

    </p>
  </div>
</div>

